import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-criar-conta',
  templateUrl: './criar-conta.page.html',
  styleUrls: ['./criar-conta.page.scss'],
})
export class CriarContaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
